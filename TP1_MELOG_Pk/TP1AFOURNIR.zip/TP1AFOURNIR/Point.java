//Classe Point

public class Point {
	protected int x;
	protected int y;
	
	public Point(int a,int b) {
		// Constructeur d'un point ayant les coordonnées passées en paramètres
	}
	
	public Point(Point p) {
		// Constructeur d'un point ayant les mêmes coordonnées que le point p
	}
	
	public int getX() {
		// retourne l'abscisse du point
	}
	
	public int getY() {
		// retourne l'ordonnée du point
	}
	
	public void translater(int a,int b) {
		// change les coordonnées du point
	}
	public Point translaterP(int a,int b) {
		// crée un nouveau point (copie du point) translaté
	}
	public String toString() {
		return("abscisse : "+x+", ordonnée : "+y);
		// La méthode toString() est définie dans la classe Object dont toute classe java hérite
		// elle est redéfinie ici pour renvoyer une chaîne de caractères qui décrit bien l'objet.
	}
}
		
	
	
